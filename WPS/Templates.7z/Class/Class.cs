﻿namespace $rootnamespace$
{
    public class $safeitemrootname$
    {
    }
}
