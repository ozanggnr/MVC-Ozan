﻿namespace $rootnamespace$
{
    public interface $safeitemrootname$
    {
    }
}
